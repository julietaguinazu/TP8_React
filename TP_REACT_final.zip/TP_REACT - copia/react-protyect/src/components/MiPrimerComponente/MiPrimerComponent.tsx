import React from "react"
import { FC } from "react";

//declaracion de la interfaz
interface IPropsMiPrimerComponent{
    text: string;
    color: string;

}

export const MiPrimerComponent: FC<IPropsMiPrimerComponent> = ({
    text,
    color,

}) =>{
    return (
    <div style={{color: '${color}'}}> 
    <p></p>
    {text}
    </div>
    );
};