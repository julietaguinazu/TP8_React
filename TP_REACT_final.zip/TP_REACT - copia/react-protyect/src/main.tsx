import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import { MiPrimerComponent } from './components/MiPrimerComponente/MiPrimerComponent'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <MiPrimerComponent text={"Texto de Porpiedades" } color='red'/>
    <MiPrimerComponent text={"Texto de Porpiedades numero 2" } color="#000"/>

  </StrictMode>,
);
